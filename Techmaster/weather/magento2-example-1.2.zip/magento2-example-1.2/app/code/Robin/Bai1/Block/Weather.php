<?php

namespace Robin\Bai1\Block;

class Weather extends \Magento\Framework\View\Element\Template
{
    protected function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
}