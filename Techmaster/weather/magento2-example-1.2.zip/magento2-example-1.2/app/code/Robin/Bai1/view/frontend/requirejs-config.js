var config = {
    paths: {
        "simple_weather": "Robin_Bai1/js/jquery.simpleWeather.min"
    },
    shim: {
        "simple_weather": ["jquery"]
    }
};